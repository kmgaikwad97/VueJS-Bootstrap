<template>
  <!-- <Navbar /> -->
  <div>
    <Carousel />
    <Main />
    <Footer />
  </div>
  <!-- <Footer /> -->
</template>

<script>
// import Navbar from "../components/Navbar.vue";
// import Footer from "../components/Footer.vue";
import Carousel from "../components/Carousel.vue";
import Main from "../components/Main.vue";
import Footer from "../components/Footer.vue";

export default {
  name: "Home",
  components: {
    // Navbar,
    // Footer,
    Carousel,
    Main,
    Footer,
  },
};
</script>