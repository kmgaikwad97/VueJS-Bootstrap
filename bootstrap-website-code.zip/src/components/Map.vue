<template>
  <iframe
    src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d9910.678011269529!2d0.125367!3d51.61094400000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a391bf87eca5%3A0xab394731bb9cc927!2s973%2C%2058%20Peregrine%20Rd%2C%20Ilford%20IG6%203SZ%2C%20UK!5e0!3m2!1sen!2sin!4v1654513585741!5m2!1sen!2sin"
    width="350"
    height="250"
    style="border: 0"
    class="size"
    allowfullscreen=""
    loading="lazy"
    referrerpolicy="no-referrer-when-downgrade"
  ></iframe>
</template>

<style scoped>
.size {
  width: 25vw;
  height: 15vw;
}

@media only screen and (max-width: 766px) {
  .size {
    width: 95%;
    height: 70vw;
  }
}

@media only screen and (max-width: 766px) {
  .size {
    width: 95%;
    height: 70vw;
  }
}
</style>